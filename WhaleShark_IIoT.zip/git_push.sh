git add .
git commit -m 'clean code lvl by flake8'
git push
